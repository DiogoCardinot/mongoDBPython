// Package proto contains the compiled protobuf structs from WhatsApp's protobuf schema.
package proto
