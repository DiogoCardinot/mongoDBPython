---
name: Open issue
about: For bug reports and feature requests directly related to whatsmeow

---
