// Package ecc provides a way to generate, sign, and use Elliptic-Curve
// X25519 Cryptography keys.
package ecc
