package medium

// MaxValue is the maximum possible integer value.
const MaxValue uint32 = 0xFFFFFF
