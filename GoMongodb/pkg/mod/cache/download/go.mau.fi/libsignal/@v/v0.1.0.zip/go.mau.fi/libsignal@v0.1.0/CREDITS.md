Credits
=======

* [William Edwards](mailto:william@usedust.com)
* [Eric Hernandez](mailto:eric@usedust.com)

## Special Thanks

* Moxie Marlinspike
* Trevor Perrin
