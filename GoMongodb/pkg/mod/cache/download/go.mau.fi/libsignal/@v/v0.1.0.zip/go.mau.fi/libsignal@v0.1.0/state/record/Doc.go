// Package record provides the state and record of an ongoing double
// ratchet session.
package record
